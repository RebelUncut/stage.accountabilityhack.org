A minimal jQuery modal that works with your CSS.

[Read Full Documentation](http://flaviusmatis.github.com/easyModal.js/)